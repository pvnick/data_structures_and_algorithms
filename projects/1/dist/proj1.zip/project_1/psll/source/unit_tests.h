#ifndef _UNIT_TESTS_H_
#define _UNIT_TESTS_H_
#include "PSLL.h"

template<typename T>
using LIST = cop3530::PSLL<T>;

#endif
