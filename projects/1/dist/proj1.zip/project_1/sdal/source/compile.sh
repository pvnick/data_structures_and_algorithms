#!/bin/sh

g++ -g --std=c++11 -I"$(pwd)/../../" *.cpp -o unit_tester
