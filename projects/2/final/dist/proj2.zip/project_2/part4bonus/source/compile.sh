#!/bin/sh

g++ --std=c++11 *.cpp -o run_tests
